import pandas as pd
import plotly.express as px
import streamlit as st
from utils import load_all_developers_dataset
from io import BytesIO
import pypistats

from program_evaluation import process_input, create_ppt_report, program_evaluation
from utils import load_all_developers_dataset

def total_commits_per_month(df):
    df["month_year"] = pd.to_datetime(df["month_year"], format="%B_%Y")
    total_commits_df = df[df["month_year"] >= "2023-01-01"].groupby([pd.Grouper(key="month_year", freq="M"), "developer"]).agg({"total_commits": "sum"}).reset_index()
    total_commits_df["classification"] = pd.cut(total_commits_df["total_commits"], bins=[-1, 9, 19, float("inf")], labels=["Low-level active (<10 commits)", "Moderately active (10-19 commits)", "Highly involved (20+ commits)"])
    total_commits_df = total_commits_df.groupby(["month_year", "classification"])["total_commits"].sum().reset_index()
    total_commits_df["month_year"] = total_commits_df["month_year"].dt.strftime("%B %Y")
    return total_commits_df

def commits_growth_rate(df):
    total_commits_df = total_commits_per_month(df)
    total_commits_df["month_year"] = pd.to_datetime(total_commits_df["month_year"])
    total_commits_df["year"] = total_commits_df["month_year"].dt.year
    total_commits_df["growth_rate"] = total_commits_df.groupby("year")["total_commits"].pct_change()
    total_commits_df["month_year"] = total_commits_df["month_year"].dt.strftime("%B %Y")
    return total_commits_df

def total_developers_per_month(df):
    df["month_year"] = pd.to_datetime(df["month_year"], format="%B_%Y")
    total_developers_df = df[df["month_year"] >= "2023-01-01"].groupby([pd.Grouper(key="month_year", freq="M"), "developer"]).agg({"total_commits": "sum"}).reset_index()
    total_developers_df = total_developers_df[total_developers_df["total_commits"] > 0]
    total_developers_df["classification"] = pd.cut(total_developers_df["total_commits"], bins=[-1, 9, 19, float("inf")], labels=["Low-level active (<10 commits)", "Moderately active (10-19 commits)", "Highly involved (20+ commits)"])
    total_developers_df = total_developers_df.groupby(["month_year", "classification"]).size().reset_index(name="total_developers")
    total_developers_df["month_year"] = total_developers_df["month_year"].dt.strftime("%B %Y")
    return total_developers_df

def developers_growth_rate(df):
    total_developers_df = total_developers_per_month(df)
    total_developers_df["month_year"] = pd.to_datetime(total_developers_df["month_year"])
    total_developers_df["year"] = total_developers_df["month_year"].dt.year
    total_developers_df["growth_rate"] = total_developers_df.groupby(["year", "classification"])["total_developers"].pct_change()
    total_developers_df["month_year"] = total_developers_df["month_year"].dt.strftime("%B %Y")
    return total_developers_df

def classify_developers_per_month(df):
    df["month_year"] = pd.to_datetime(df["month_year"], format="%B_%Y")
    last_month = df["month_year"].max()
    last_month_df = df[df["month_year"] == last_month]
    classification_df = last_month_df.groupby("developer")["total_commits"].sum().reset_index()
    classification_df["classification"] = pd.cut(classification_df["total_commits"], bins=[-1, 9, 19, float("inf")], labels=["Low-level active (<10 commits)", "Moderately active (10-19 commits)", "Highly involved (20+ commits)"])
    return classification_df

def main():
    df = load_all_developers_dataset()
    max_available_month = df["month_year"].max().strftime("%Y-%m")
    st.set_page_config(page_title="Starknet Star Tracker")
    st.sidebar.title("Menu")
    app_mode = st.sidebar.selectbox("Select Application", ["Developer Insights", "Program Evaluation"])

    if app_mode == "Developer Insights":

        try:
            with open("./github-metrics/assets/style.css") as f:
                st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
        except:
            try:
                with open("../assets/style.css") as f:
                    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
            except:
                with open("assets/style.css") as f:
                    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
                    
        st.title("Developer Insights")
        total_commits_df = total_commits_per_month(df)
        fig_total_commits = px.bar(total_commits_df, x="month_year", y="total_commits", color="classification", title="Total Commits per Month")
        fig_total_commits.update_yaxes(rangemode="tozero")
        st.plotly_chart(fig_total_commits)
        
        
        commits_growth_df = commits_growth_rate(df)
        fig_commits_growth = px.bar(commits_growth_df, x="month_year", y="growth_rate", color="classification", title="Commits Growth Rate (Year-over-Year)")
        fig_commits_growth.update_yaxes(rangemode="tozero")
        st.plotly_chart(fig_commits_growth)
        
        total_developers_df = total_developers_per_month(df)
        fig_total_developers = px.bar(total_developers_df, x="month_year", y="total_developers", color="classification", title="Total Developers per Month")
        fig_total_developers.update_yaxes(rangemode="tozero")
        st.plotly_chart(fig_total_developers)
        
        developers_growth_df = developers_growth_rate(df)
        fig_developers_growth = px.bar(developers_growth_df, x="month_year", y="growth_rate", color="classification", title="Developers Growth Rate (Year-over-Year)")
        fig_developers_growth.update_yaxes(rangemode="tozero")
        st.plotly_chart(fig_developers_growth)
        
        st.subheader("Developer Classification for the Last Month")
        classification_df = classify_developers_per_month(df)
        st.dataframe(classification_df)

        package = "starknet-py"

        # Get monthly download stats for the last 12 months
        downloads = pypistats.overall(package, period='month', format='pandas')

        print(downloads.tail(12))
   
    elif app_mode == "Program Evaluation":
        program_evaluation()
        

if __name__ == "__main__":
    main()